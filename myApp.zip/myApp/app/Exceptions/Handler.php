<?php

namespace App\Exceptions;
use Illuminate\Http\Request;
use Throwable;

use Exception;

class Handler extends Exception
{
    //
}
