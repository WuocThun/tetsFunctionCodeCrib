<?php $__env->startSection('title','Bộ lọc'); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('fe.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('searchBar'); ?>
    <?php echo $__env->make('fe.inc.search_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('hotZone'); ?>
    <?php echo $__env->make('fe.inc.hot_zone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <style>
        .call-btn {
            background-color: #007bff;
            border: none;
            font-size: 14px;
            color: white;
        }
    </style>
    <section class="search-results">
        <div class="container search-results-container">
            <div class="results-left">
                <h2>Tổng <?php echo e(count($rooms)); ?> kết quả</h2>
                <div class="sort-options">
                    <span>Sắp xếp: </span>
                    <button onclick="window.location.href='<?php echo e('/bo-loc/phong?orderby=mac-dinh'); ?>'" class="btn sort-btn">Mặc định</button>
                    <button onclick="window.location.href='<?php echo e('/bo-loc/phong?orderby=moi-nhat'); ?>'" class="btn sort-btn">Mới nhất</button>

                </div>
                <?php if($rooms->isEmpty()): ?>
                    <h3>Hiện không có phòng khả dụng</h3>
            </div>
            <?php echo $__env->make('fe.inc.fitler_blogs_right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php else: ?>
                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room => $room1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $styles = $room1->vipPackage->getDisplayStyles();
                    ?>
                        <a href="<?php echo e(route('getRoom',$room1->slug)); ?>" style="text-decoration: none;">
                            <div class="result-item">
                                <?php
                                    $images = json_decode($room1->image, true);
                                ?>
                                <img src="<?php echo e(asset('uploads/fe/img/room1.jpg')); ?>" alt="Ký túc xá Tân Bình">
                                <div class="result-info">
                                    <h3 style="color: <?php echo e($styles['color']); ?>; font-weight: <?php echo e($styles['fontWeight']); ?>; text-transform: <?php echo e($styles['textTransform']); ?>;" ><?php echo e($room1->title); ?></h3>
                                    <p><?php echo e(number_format($room1->price,0,',', '.')); ?> nghìn/tháng - <?php echo e($room1->area); ?>m² </p>
                                    <p><?php echo e($room1->full_address); ?></p>

                                    
                                    <div class="contact-options">
                                        <button class="btn  call-btn">Gọi <?php echo e($room1->phone_number); ?></button>
                                        <a href="https://zalo.me/<?php echo e($room1->phone_number); ?>" target="_blank"> <button class="btn zalo-btn">Nhắn Zalo</button> </a>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="pagination">
                            <?php if($rooms->onFirstPage()): ?>
                                <button class="prev" disabled>« Trang trước</button>
                            <?php else: ?>
                                <a href="<?php echo e($rooms->previousPageUrl()); ?>" class="prev">« Trang trước</a>
                            <?php endif; ?>

                            <?php for($page = 1; $page <= $rooms->lastPage(); $page++): ?>
                                <a href="<?php echo e($rooms->url($page)); ?>" class="page <?php echo e($page == $rooms->currentPage() ? 'active' : ''); ?>"><?php echo e($page); ?></a>
                            <?php endfor; ?>

                            <?php if($rooms->hasMorePages()): ?>
                                <a href="<?php echo e($rooms->nextPageUrl()); ?>" class="next">Trang sau »</a>
                            <?php else: ?>
                                <button class="next" disabled>Trang sau »</button>
                            <?php endif; ?>
                        </div>

        </div>

            <?php echo $__env->make('fe.inc.fitler_blogs_right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
        </div>

    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('overView'); ?>
    <?php echo $__env->make('fe.inc.over_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('fe.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('fe.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/fe/fitler_price.blade.php ENDPATH**/ ?>