<?php $__env->startSection('main'); ?>
    <style>
        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
    <main role="main" class="ml-sm-auto col">
        <div class="no-print">
            <?php echo $__env->make('admin_core.inc.sub_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="no-print">
            <a href="<?php echo e(route('admin.motel.create')); ?>">
                <button type="button" class="mb-3 mt-2 btn btn-secondary">Thêm phòng</button>
            </a>
        </div>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <img src="<?php echo e(asset('uploads/logoCodeCrib.png')); ?>" class="rounded mx-auto d-none d-print-block" alt="...">
            <div class="card-header">
                <p>Ngày tạo thanh toán: <?php echo e(\Carbon\Carbon::parse($invoice->created_at)->format('d/m/Y')); ?> </p>
                <p>Tên phòng : <?php echo e($getMotelName->name); ?></p>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">Loại tiền</th>
                        <th scope="col">Chỉ số</th>
                        <th scope="col">Số tiền</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <th scope="row">Tiền phòng</th>
                        <td></td>
                        <td><?php echo e(number_format($invoice->money,0,',', '.')); ?> VNĐ</td>
                    </tr>
                    <tr>
                        <th scope="row">Tiền điện</th>
                        <td>( <?php echo e($invoice->new_electric); ?>kWH - <?php echo e($invoice->old_electric); ?>kWH
                            = <?php echo e($invoice->new_electric - $invoice->old_electric); ?> kWH
                            x <?php echo e(number_format($invoice->money_electric,0,',', '.')); ?> VNĐ) =
                        </td>
                        <td><?php echo e(number_format($invoice->electric_fee,0,',', '.')); ?> VNĐ</td>
                    </tr>
                    <tr>
                        <th scope="row">Tiền nước</th>
                        <td>( <?php echo e($invoice->new_water); ?>kWH - <?php echo e($invoice->old_water); ?>kWH
                            = <?php echo e($invoice->new_water- $invoice->old_water); ?> kWH
                            x <?php echo e(number_format($invoice->money_water,0,',', '.')); ?> VNĐ) =
                        </td>
                        <td><?php echo e(number_format($invoice->water_fee,0,',', '.')); ?> VNĐ</td>
                    </tr>
                    <?php if(!isset($invoice->prepay)): ?>

                    <?php else: ?>

                    <tr>
                        <th scope="row">Số tiền ban đầu</th>
                        <td></td>
                        <td  class="fw-bold text-primary"><?php echo e(number_format($invoice->all_money,0,',', '.')); ?> VNĐ</td>
                    </tr>
                    <tr>
                        <th scope="row">Thanh toán trước</th>
                        <td>Số tiền phòng hiện tại - tiền đã trả trước = <?php echo e(number_format($invoice->prepay,0,',', '.')); ?> VNĐ
                        </td>
                        <td><?php echo e(number_format($invoice->prepay,0,',', '.')); ?> VNĐ</td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <th scope="row">Tiền khác ( WIFI + RÁC,..)</th>
                        <th ></th>
                        <td class="fw-bold text-danger"><?php echo e(number_format($invoice->money_another,0,',', '.')); ?> VNĐ</td>
                    </tr>
                    <tr>
                        <th scope="row"></th>
                        <td class="fw-bold text-danger">Tổng tiền</td>
                        <td class="fw-bold text-danger"><?php echo e(number_format($invoice->total_amount,0,',', '.')); ?> VNĐ</td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="no-print row ml-3 mb-3">
                <div class="col-md-4">
                    <button onclick="window.print()" class="btn btn-info">In hoá đơn</button>
                </div>
                <div class="col-md-4">
                    <form action="<?php echo e(route('admin.invoices.acceptPay', $invoice->id)); ?>" method="POST"
                          onsubmit="return confirm('Bạn có chắc chắn muốn thanh toán hóa đơn này?');">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-warning">Thanh toán</button>
                    </form>
                </div>
                <div class="col-md-4">
                    <button class="btn btn-danger" data-bs-toggle="modal"
                            data-bs-target="#addMemberModal<?php echo e($invoice->id); ?>">
                        Thanh toán và nợ
                    </button>
                </div>
            </div>
        </div>
    </main>
    <div class="modal fade" id="addMemberModal<?php echo e($invoice->id); ?>" tabindex="-1" aria-labelledby="addMemberModalLabel<?php echo e($invoice->id); ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addMemberModalLabel<?php echo e($invoice->id); ?>">Thông tin hoá đơn</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('admin.invoices.prepay')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12 mb-4">
                                    <label for="old_electric_<?php echo e($invoice->id); ?>" class="form-label text-dark">Tổng tiền</label>
                                    <input type="text" class="form-control" disabled value="<?php echo e(number_format($invoice->total_amount,0,',', '.')); ?> VNĐ"  name="">
                                    <input type="text" class="form-control" hidden value="<?php echo e($invoice->id); ?>"  name="invoiceId">
                                </div>
                                <div class="col-md-12 mb-4">
                                    <label for="prepaid_amount_<?php echo e($invoice->id); ?>" class="form-label text-dark">Số tiền thanh toán trước</label>
                                    <input type="number" id="prepaid_amount_<?php echo e($invoice->id); ?>"
                                           class="form-control currency-input"
                                           max="<?php echo e($invoice->total_amount); ?>"
                                           min="0"
                                           name="prepay"
                                           placeholder="Nhập số tiền thanh toán trước">
                                </div>
                                <div class="col-md-12 mb-4">
                                    <label for="remaining_amount_<?php echo e($invoice->id); ?>" class="form-label text-dark">Số tiền còn nợ</label>
                                    <input type="number" id="remaining_amount_<?php echo e($invoice->id); ?>"
                                           class="form-control currency-input"
                                           readonly
                                           name="total_amount"
                                           value="<?php echo e($invoice->total_amount); ?>">
                                </div>
                            </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                            <button type="submit" class="btn btn-info">Trả trước</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<script>
    document.querySelector('.currency-input').addEventListener('input', function (e) {
        const max = parseInt(e.target.getAttribute('max'));
        const min = parseInt(e.target.getAttribute('min'));
        let value = parseInt(e.target.value);

        if (value > max) {
            e.target.value = max; // Nếu vượt quá max, tự động đặt giá trị bằng max
        } else if (value < min) {
            e.target.value = min; // Nếu nhỏ hơn min, tự động đặt giá trị bằng min
        }
    });
</script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const prepaidInput = document.getElementById('prepaid_amount_<?php echo e($invoice->id); ?>');
            const remainingInput = document.getElementById('remaining_amount_<?php echo e($invoice->id); ?>');
            const totalAmount = <?php echo e($invoice->total_amount); ?>;

            prepaidInput.addEventListener('input', function () {
                let prepaidValue = parseFloat(prepaidInput.value) || 0; // Lấy giá trị nhập hoặc 0 nếu trống
                if (prepaidValue > totalAmount) {
                    prepaidValue = totalAmount; // Không cho phép vượt quá tổng số tiền
                    prepaidInput.value = prepaidValue;
                }
                const remainingValue = totalAmount - prepaidValue; // Tính số tiền còn nợ
                remainingInput.value = remainingValue.toFixed(0); // Hiển thị số tiền còn nợ
            });
        });

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin_core/content/invoices/pay.blade.php ENDPATH**/ ?>