









































































<header class="navbar">
    <div class="navbar-top">
        <div class="logo">


            <img class="img-fluid" src="<?php echo e(asset('uploads/logoCodeCrib.png')); ?>">
        </div>
        <?php if(Auth::check()): ?>
        <div class="user-info">
            <div class="imguser">
            </div>

            <div class="flexinfo">
                <span>Xin chào, <b><?php echo e(Auth::user()->name); ?></b></span>
                <span>Mã tài khoản: <?php echo e(Auth::user()->rand_code_user); ?></span>
                <span>TK Chính: <b><?php echo e(number_format(Auth::user()->balance, 0, ',', '.')); ?> VNĐ</b></span>
            </div>
            <span class="icon"><a href="<?php echo e(route('wishlist.list')); ?>">Yêu thích</a></span>
            <span class="icon">Quản lý tài khoản</span>

            <button class="btn-dang-tin">Đăng tin miễn phí</button>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                    <?php echo e(__('Log Out')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
            </form>
            <?php else: ?>
                <div class="user-info">



                    <div class="flexinfo">
                    </div>
                    <a href="<?php echo e(route('getLogin')); ?>" style="text-decoration: none;">
                        <button class="btn">Đăng nhập</button>
                    </a>

                    <a href="<?php echo e(route('getReginster')); ?>" style="text-decoration: none;">
                        <button class="btn highlight">Đăng ký</button>
                    </a>
            <?php endif; ?>

        </div>
    </div>
    <nav class="navbar-bottom">
        <nav class="main-nav">
            <ul class="text-center d-flex justify-content-center">
                <li class="mx-3">
                    <a class="" href="<?php echo e(route('welcome')); ?>">Trang chủ</a>
                </li>
                <?php $__currentLoopData = $clasRoom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class => $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="mx-3"><a class="" href="<?php echo e(route('laydichvu', $cl->slug)); ?>"><?php echo e($cl->title); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li class="mx-3"><a class="" href="<?php echo e(route('room-requests.index')); ?>">Đăng ký phòng trọ</a></li>
                <li class="mx-3"><a class="" href="<?php echo e(route('viewRequests')); ?>">Đăng ký ở ghép</a></li>
                <li class="mx-3"><a class="" href="<?php echo e(route('indexBlog')); ?>">Tin tức</a></li>
                <li class="mx-3"><a class="" href="<?php echo e(route('dichvu')); ?>">Dịch vụ</a></li>
            </ul>
        </nav>
    </nav>
</header>
<?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/fe/inc/header.blade.php ENDPATH**/ ?>