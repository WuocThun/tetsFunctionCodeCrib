<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin_core.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>

    <main role="main" class="ml-sm-auto col">
        <?php echo $__env->make('admin_core.inc.sub_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <a href="<?php echo e(route('admin.motel.create')); ?>">
            <button type="button" class="mb-3 mt-2 btn btn-secondary">Thêm phòng</button>
        </a>
        
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <?php $__currentLoopData = $motels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal fade" id="addMemberModal<?php echo e($motel->id); ?>" tabindex="-1"
                     aria-labelledby="addMemberModalLabel<?php echo e($motel->id); ?>" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="addMemberModalLabel<?php echo e($motel->id); ?>">Thông tin hoá đơn</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('admin.invoices.create')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="motel_id" value="<?php echo e($motel->id); ?>">

                                    <div class="row">
                                        <div class="col-md-6 mb-4">
                                            <label for="new_electric_<?php echo e($motel->id); ?>" class="form-label text-dark">Chỉ số
                                                điện mới:</label>
                                            <input type="number" class="form-control" name="new_electric"
                                                   min="<?php echo e($motel->default_electric); ?>" required>
                                            <input type="number" hidden class="form-control" name="money_water"
                                                   value="<?php echo e($motel->money_water); ?>" required>
                                            <input type="number" hidden class="form-control" name="money_electric"
                                                   value="<?php echo e($motel->money_electric); ?>" required>
                                            <input type="number" hidden class="form-control" name="money"
                                                   value="<?php echo e($motel->money); ?>" required>
                                            <input type="number" hidden class="form-control" name="money_another"
                                                   value="<?php echo e($motel->money_another); ?>" required>
                                            <input type="number" hidden class="form-control" name="money_wifi"
                                                   value="<?php echo e($motel->money_wifi); ?>" required>


                                        </div>
                                        <div class="col-md-6 mb-4">
                                            <label for="old_electric_<?php echo e($motel->id); ?>" class="form-label text-dark">Chỉ số
                                                điện cũ:</label>
                                            <input type="number" class="form-control"
                                                   value="<?php echo e($motel->default_electric); ?>" name="old_electric" readonly>
                                        </div>
                                        <div class="col-md-6 mb-4">
                                            <label for="new_water_<?php echo e($motel->id); ?>" class="form-label text-dark">Chỉ số
                                                nước mới:</label>
                                            <input type="number" class="form-control" name="new_water"
                                                   min="<?php echo e($motel->default_water); ?>" required>
                                        </div>
                                        <div class="col-md-6 mb-4">
                                            <label for="old_water_<?php echo e($motel->id); ?>" class="form-label text-dark">Chỉ số
                                                nước cũ:</label>
                                            <input type="number" class="form-control" value="<?php echo e($motel->default_water); ?>"
                                                   name="old_water" readonly>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng
                                        </button>
                                        <button type="submit" class="btn btn-info">Tạo hoá đơn</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card room-card">
                        <!-- Header -->
                        <div class="card-header text-center bg-warning">
                            <img class="img-fluid" src="<?php echo e(asset('uploads/logoCodeCrib.png')); ?>">
                        </div>
                        <!-- Body -->
                        <div class="card-body">
                            <h6 class="room-name"><?php echo e($motel->name); ?></h6>
                            <ol class="list-group list-group-numbered">
                                <li class="list-group-item d-flex justify-content-between align-items-start">
                                    <div class="ms-2 me-auto">
                                        <div class="fw-bold">Yêu cầu tham gia phòng</div>
                                        <button type="button" class="fs-m btn-info" data-bs-toggle="modal"
                                                data-bs-target="#requestModal<?php echo e($motel->id); ?>">
                                            Xem danh sách yêu cầu
                                        </button>

                                    </div>
                                    <span class="badge bg-info rounded-pill"><?php echo e(count($motel->roomRequests )); ?></span>
                                </li>
                            </ol>
                            <div class="modal fade" id="requestModal<?php echo e($motel->id); ?>" tabindex="-1" aria-labelledby="requestModalLabel<?php echo e($motel->id); ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="requestModalLabel<?php echo e($motel->id); ?>">Danh sách yêu cầu tham gia phòng</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <?php if($motel->roomRequests->isNotEmpty()): ?>
                                                <?php $__currentLoopData = $motel->roomRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="mb-3">
                                                        <table class="table">
                                                            <thead>
                                                            <tr>
                                                                <th scope="col">tên người dùng</th>
                                                                <th scope="col">Trạng thái</th>
                                                                <th scope="col">Hành động</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            <tr>
                                                                <td><?php echo e($request->user->name); ?></td>
                                                                <td>
                                                                    <?php if($request->status == 'pending'): ?> Chờ duyệt
                                                                    <?php elseif($request->status == 'accepted'): ?> Đã chấp nhận
                                                                    <?php elseif($request->status == 'rejected'): ?> Đã từ chối
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <?php if($request->status == 'pending'): ?>
                                                                    <form action="<?php echo e(route('room-requests.accept', $request->id)); ?>" method="POST" style="display: inline;">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('PATCH'); ?>
                                                                        <button type="submit" class=" btn-success">Chấp nhận</button>
                                                                    </form>
                                                                        <form action="<?php echo e(route('room-requests.reject', $request->id)); ?>" method="POST" style="display: inline;">
                                                                            <?php echo csrf_field(); ?>
                                                                            <?php echo method_field('PATCH'); ?>
                                                                            <button type="submit" class=" btn-danger">Từ chối</button>
                                                                        </form>
                                                                    <?php elseif($request->status == 'accepted'): ?>
                                                                        <form action="<?php echo e(route('room-requests.accept', $request->id)); ?>" method="POST" style="display: inline;">
                                                                            <?php echo csrf_field(); ?>
                                                                            <?php echo method_field('PATCH'); ?>
                                                                            <button disabled type="submit" class=" btn-success">Chấp nhận</button>
                                                                        </form>
                                                                        <?php else: ?>
                                                                    <form action="<?php echo e(route('room-requests.reject', $request->id)); ?>" method="POST" style="display: inline;">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('PATCH'); ?>
                                                                        <button disabled type="submit" class=" btn-danger">Từ chối</button>
                                                                    </form>
                                                                    <?php endif; ?>
                                                                </td>
                                                            </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <hr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <p>Không có yêu cầu nào.</p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="room-info my-3">
                                <div class="row mb-2">
                                    <div class="col-md-6">
                                        <button class="btn btn-primary rounded-circle status-room">
                                            Hiện có: <?php echo e($motel->users_count); ?> người
                                        </button>
                                    </div>
                                    <div class="col-md-6">
                                        <?php if($motel->users_count < $motel->total_member): ?>
                                            <button class="btn btn-secondary room-type-btn status-room">
                                                Phòng trống: <?php echo e($motel->total_member - $motel->users_count); ?> chỗ
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-success room-type-btn status-room" disabled>
                                                Phòng đã đầy
                                            </button>
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <div class="actions d-flex justify-content-between">
                                    <button class="btn btn-info"
                                            onclick="window.location.href='<?php echo e(route('admin.motel.addUserMotel', ['id' => $motel->id])); ?>'">
                                        <i class="fas fa-user"></i>
                                    </button>
                                    <button class="btn btn-warning"
                                            onclick="window.location.href='<?php echo e(route('admin.motel.edit', ['id' => $motel->id])); ?>'">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-purple" data-bs-toggle="modal"
                                            data-bs-target="#addMemberModal<?php echo e($motel->id); ?>">
                                        <i class="fas fa-calendar"></i>
                                    </button>

                                    <form action="<?php echo e(route('admin.motel.destroy', ['id' => $motel->id])); ?>"
                                          method="POST" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger"
                                                onclick="return confirm('Bạn có chắc chắn muốn xóa không?')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>

                                </div>
                            </div>
                            <div class="card-footer text-center row">
                                <div class="col-md-6  ">
                                    <p>Ngày tính
                                        tiền: <?php echo e(\Carbon\Carbon::parse($motel->money_date)->format('d/m/Y')); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p>Tiền phòng: <?php echo e(number_format($motel->money,0,',', '.')); ?> đ</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </main>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_core.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin_core/content/motel/index.blade.php ENDPATH**/ ?>