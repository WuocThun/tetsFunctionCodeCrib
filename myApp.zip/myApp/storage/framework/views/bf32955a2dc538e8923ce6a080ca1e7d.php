<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('fe.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>






<style>
    p {
        max-width: 100%; /* Giới hạn chiều rộng */
        max-height: 150px; /* Giới hạn chiều cao */
        overflow-y: auto; /* Hiển thị thanh cuộn dọc nếu cần */
        word-wrap: break-word; /* Chia nhỏ từ để không bị tràn */
    }

</style>
<?php $__env->startSection('main'); ?>
    <?php
        $images = json_decode($room->image, true);
            $styles = $room->vipPackage->getDisplayStyles();
            $styles = $room->vipPackage->getDisplayStyles();

    ?>



    <section class="search-results">

        <div class="container search-results-container">

            <div class="results-left">
                <div id="breadcrumb">
                    <ol class="clearfix">
                        <li class="first link">
                            <a href="#" title="Cho thuê phòng trọ">
                                <span><?php echo e($ClassRoom->title); ?></span>
                            </a>
                        </li>
                        <li class="link link">
                            <a href="#" title="<?php echo e($provinceData['province_name']); ?>">
                                <span><?php echo e($provinceData['province_name']); ?></span>
                            </a>
                        </li>
                        <li class="link link">
                            <a href="#" title="<?php echo e($getDistrict); ?>">
                                <span><?php echo e($getDistrict); ?></span>

                            </a>
                        </li>
                        <li class="link last">
                            <span><?php echo e($room->title); ?></span>
                        </li>
                    </ol>
                </div>

                <div class="item-detail">
                    <?php if(!empty($images)): ?>
                        <!-- Carousel -->
                        <div id="demo" class="carousel slide" data-bs-ride="carousel">
                            <!-- Indicators/dots -->
                            <div class="carousel-indicators">
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button
                                        type="button"
                                        data-bs-target="#demo"
                                        data-bs-slide-to="<?php echo e($index); ?>"
                                        class="<?php echo e($index == 0 ? 'active' : ''); ?>"
                                    ></button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <!-- The slideshow/carousel -->
                            <div class="carousel-inner">
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                                        <img
                                            src="<?php echo e(asset('uploads/rooms/' . $img)); ?>"
                                            alt="Room Image <?php echo e($index + 1); ?>"
                                            class="d-block h-100"
                                            style="width: 100%"
                                        />
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <!-- Left and right controls/icons -->
                            <button
                                class="carousel-control-prev"
                                type="button"
                                data-bs-target="#demo"
                                data-bs-slide="prev"
                            >
                                <span class="carousel-control-prev-icon"></span>
                            </button>
                            <button
                                class="carousel-control-next"
                                type="button"
                                data-bs-target="#demo"
                                data-bs-slide="next"
                            >
                                <span class="carousel-control-next-icon"></span>
                            </button>
                        </div>
                    <?php else: ?>
                        <p>No images available</p>
                    <?php endif; ?>





                        <h3 style="color: <?php echo e($styles['color']); ?>; font-weight: <?php echo e($styles['fontWeight']); ?>; text-transform: <?php echo e($styles['textTransform']); ?>;" ><?php echo e($room->title); ?></h3>

                        <div class="address">
                        <div class="iconaddress"></div>
                        <span>
                    <img class="addr_icone" id="addr_icone" width="10px" height="10px" src="<?php echo e(asset('uploads/maps-and-flags.png')); ?>">
                        </span>
                        <span style="margin-left: 10px">Địa chỉ: <?php echo e($room->full_address); ?> </span>
                    </div>

                    <div class="attributes">
                        <div class="iconprice"></div>
                        <span
                            style="
                  color: #16c784;
                  font-weight: bold;
                  font-size: 18px;
                  margin-left: 10px;
                "><?php echo e(number_format($room->price,0,',', '.')); ?> nghìn/tháng</span>
                        <div class="iconacreage"></div>
                        <span style="margin-left: 10px"> <?php echo e($room->area); ?> m <sup>2</sup></span>
                        <div class="iconclock"></div>
                        <span style="margin-left: 10px"><?php echo e($timePosted); ?></span>
                        <div class="iconhastag"></div>
                        <span style="margin-left: 10px">Mã phòng: <?php echo e($room->id); ?></span>
                    </div>

                    <h3 style="margin-top: 20px">Thông tin mô tả</h3>

                        <div class="content-container">
                            <?php
                            echo($room->description);
                        ?>                </div>
                    <table class="table table table-striped">
                        <tbody>
                        <tr>
                            <td class="name">Mã phòng:</td>
                            <td><?php echo e($room->id); ?></td>
                        </tr>
                        <tr>
                            <td class="name">Chuyên mục:</td>
                            <td>
                                <a
                                    style="text-decoration: underline"
                                    title="<?php echo e($getDistrict); ?>"
                                    href="#"><strong>Cho thuê phòng trọ <?php echo e($getDistrict); ?></strong></a>
                            </td>
                        </tr>
                        <tr>
                            <td class="name">Khu vực</td>
                            <td>Cho thuê phòng trọ <?php echo e($provinceData['province_name']); ?>

                                
                                
                                
                            </td>
                        </tr>
                        <tr>
                            <td class="name">Loại tin rao:</td>
                            <td><?php echo e($ClassRoom->title); ?></td>
                        </tr>
                        <tr>
                            <td class="name">Đối tượng thuê:</td>
                            <?php if($room->gender_rental === 0): ?>
                                <td>Tất cả</td>
                            <?php elseif($room->gender_rental === 1): ?>
                                <td>Nam</td>
                            <?php else: ?>
                                <td>Nữ</td>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            <td class="name">Gói tin:</td>
                            <td><span style="color: #e13427"><?php echo e($vipPackages->name); ?></span></td>
                        </tr>
                        <tr>
                            <td class="name">Ngày đăng:</td>
                            <td>
                                <time title="Thứ 6, 15:33 04/10/2024">Thứ 6, 15:33 04/10/2024
                                </time>
                            </td>
                        </tr>
                        <tr>
                            <td class="name">Ngày hết hạn:</td>
                            <td>
                                <time title="Thứ 4, 13:41 09/10/2024">Thứ 4, 13:41 09/10/2024
                                </time>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    <h3>Thông tin liên hệ</h3>
                    <table class="table table table-striped">
                        <tr>
                            <td class="name">Liên hệ:</td>
                            <td><?php echo e($findUser->name); ?></td>
                        </tr>
                        <tr>
                            <td class="name">Điện thoại:</td>
                            <td><?php echo e($findUser->phone_number); ?></td>
                        </tr>
                        <tr>
                            <td class="name">Zalo</td>
                            <td><?php echo e($findUser->phone_number); ?></td>
                        </tr>
                    </table>
                    <iframe
                        src="https://maps.google.com/maps?&hl=en&q=$<?php echo e($room->full_address); ?>&t=&z=12&ie=UTF8&iwloc=B&output=embed"
                        width="850"
                        height="450"
                        style="border: 0"
                        allowfullscreen=""
                        loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade"
                    ></iframe>
                    <p>Bạn đang xem nội dung tin đăng: "<?php echo e($room->title); ?> - Mã
                        tin: #<?php echo e($room->id); ?>". Mọi thông tin liên quan đến tin đăng này chỉ mang tính chất tham khảo. Nếu
                        bạn có phản
                        hồi với tin đăng này (báo xấu, tin đã cho thuê, không liên lạc được,...), vui lòng thông báo để
                        CodeCrib có thể xử lý.</p>
                </div>

                <div class="pagination">
                    
                    
                    
                    
                    
                    
                    
                    

                    
                    
                    
                    
                    
                    
                    
                    
                    <?php echo $__env->make('fe.inc.comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
<?php echo $__env->make('fe.inc.fitler_blogs_right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('overView'); ?>
    <?php echo $__env->make('fe.inc.over_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('fe.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('fe.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/fe/chitiet.blade.php ENDPATH**/ ?>