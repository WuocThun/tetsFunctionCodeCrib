<?php $__env->startSection('main'); ?>

    <main role="main" class="ml-sm-auto col">
        <?php echo $__env->make('admin_core.inc.sub_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

    <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('welcome')); ?>">Code Crib</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboardCore')); ?>">Quản lý</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Thêm thành viên vào phòng</li>
            </ol>
        </nav>
        <div class="card">
            <div class="row">
                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'houseRenter||admin')): ?>
                <div class="col-md-6">
                    <div class="card-body">
                        <button class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#addMemberModal">Thêm thành
                            viên vào phòng
                        </button>
                    </div>
                </div>
                <?php endif; ?>
                <div class="col-md-6">

                </div>
            </div>

            <div class="card-header">
                <h4>Danh sách thành viên: <?php echo e($getMotel->name); ?></h4>
                <h5>Mật khẩu phòng: <?php echo e($getMotel->password); ?></h5>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">STT</th>
                        <th scope="col">Họ tên</th>
                        <th scope="col">Số điện thoại</th>
                        <th scope="col">Mật khẩu </th>
                        <th scope="col">Trạng thái</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $getUserRentMotel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motel => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($user->id); ?></th>
                        <td><?php echo e($user->name); ?></td>
                        <td> 0<?php echo e($user->phone_number); ?></td>
                        <td><?php echo e($getMotel->password); ?></td>
                        <td></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
    <!-- Modal -->
    <div class="modal fade" id="addMemberModal" tabindex="-1" aria-labelledby="addMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addMemberModalLabel">Thêm thành viên vào phòng</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('admin.motel.storeUserMotel',['id',$getMotel->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label text-dark">Họ tên</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                            <input type="text" class="form-control" id="motel_id" name="motel_id" value="<?php echo e($getMotel->id); ?>" hidden >
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label text-dark">Số điện thoại</label>
                            <input type="text" class="form-control" id="phone_number" name="phone_number" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label text-dark">CCCD/CMND</label>
                            <input type="text" class="form-control" name="cardIdNumber" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label text-dark">Email</label>
                            <input type="text" class="form-control" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label text-dark">Mật khẩu</label>
                            <input class="form-control" id="password" name="password" readonly
                                   value="<?php echo e($getMotel->password); ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Thêm thành viên</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin_core/content/motel/addUserMotel.blade.php ENDPATH**/ ?>