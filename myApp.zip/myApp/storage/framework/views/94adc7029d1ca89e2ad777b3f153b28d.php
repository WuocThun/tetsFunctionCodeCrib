<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin_core.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>

    <main role="main" class="ml-sm-auto col">
        <?php echo $__env->make('admin_core.inc.sub_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <a href="<?php echo e(route('admin.motel.create')); ?>">
            <button type="button" class="mb-3 mt-2 btn btn-secondary">Thêm phòng</button>
        </a>
        
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if(isset($motel)): ?>
            <div class="row">
                <div class="modal fade" id="addMemberModal<?php echo e($motel->id); ?>" tabindex="-1"
                     aria-labelledby="addMemberModalLabel<?php echo e($motel->id); ?>" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="addMemberModalLabel<?php echo e($motel->id); ?>">Thông tin hoá đơn</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('admin.invoices.create')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="motel_id" value="<?php echo e($motel->id); ?>">

                                    <div class="row">
                                        <div class="col-md-6 mb-4">
                                            <label for="new_electric_<?php echo e($motel->id); ?>" class="form-label text-dark">Chỉ số
                                                điện mới:</label>
                                            <input type="number" class="form-control" name="new_electric"
                                                   min="<?php echo e($motel->default_electric); ?>" required>
                                            <input type="number" hidden class="form-control" name="money_water"
                                                   value="<?php echo e($motel->money_water); ?>" required>
                                            <input type="number" hidden class="form-control" name="money_electric"
                                                   value="<?php echo e($motel->money_electric); ?>" required>
                                            <input type="number" hidden class="form-control" name="money"
                                                   value="<?php echo e($motel->money); ?>" required>
                                            <input type="number" hidden class="form-control" name="money_another"
                                                   value="<?php echo e($motel->money_another); ?>" required>
                                            <input type="number" hidden class="form-control" name="money_wifi"
                                                   value="<?php echo e($motel->money_wifi); ?>" required>


                                        </div>
                                        <div class="col-md-6 mb-4">
                                            <label for="old_electric_<?php echo e($motel->id); ?>" class="form-label text-dark">Chỉ số
                                                điện cũ:</label>
                                            <input type="number" class="form-control"
                                                   value="<?php echo e($motel->default_electric); ?>" name="old_electric" readonly>
                                        </div>
                                        <div class="col-md-6 mb-4">
                                            <label for="new_water_<?php echo e($motel->id); ?>" class="form-label text-dark">Chỉ số
                                                nước mới:</label>
                                            <input type="number" class="form-control" name="new_water"
                                                   min="<?php echo e($motel->default_water); ?>" required>
                                        </div>
                                        <div class="col-md-6 mb-4">
                                            <label for="old_water_<?php echo e($motel->id); ?>" class="form-label text-dark">Chỉ số
                                                nước cũ:</label>
                                            <input type="number" class="form-control" value="<?php echo e($motel->default_water); ?>"
                                                   name="old_water" readonly>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng
                                        </button>
                                        <button type="submit" class="btn btn-info">Tạo hoá đơn</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card room-card">
                        <!-- Header -->
                        <div class="card-header text-center bg-warning">
                            <img class="img-fluid" src="<?php echo e(asset('uploads/logoCodeCrib.png')); ?>">
                        </div>
                        <!-- Body -->
                        <div class="card-body">
                            <h6 class="room-name"><?php echo e($motel->name); ?></h6>
                            <ol class="list-group list-group-numbered">
                                <li class="list-group-item d-flex justify-content-between align-items-start center">
                                    <div class="ms-2 me-auto">
                                        <div class="fw-bold">Nhập mật khẩu để mở khoá</div>
                                        <button type="button" class="fs-m btn-info" data-bs-toggle="modal"
                                                data-bs-target="#requestModal<?php echo e($motel->id); ?>">
                                            Tại đây
                                        </button>
                                    </div>
                                </li>
                            </ol>
                            <div class="modal fade" id="requestModal<?php echo e($motel->id); ?>" tabindex="-1"
                                 aria-labelledby="requestModalLabel<?php echo e($motel->id); ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="requestModalLabel<?php echo e($motel->id); ?>">Danh sách yêu
                                                cầu tham gia phòng</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('admin.check.passcode')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>

                                                <div class="mb-3">
                                                    <label for="motel_id" class="form-label text-dark">Tên
                                                        phòng: <?php echo e($motel->name); ?></label>

                                                    <input type="text" name="motel_id" hidden value="<?php echo e($motel->id); ?>"
                                                           id="">
                                                </div>

                                                <div class="mb-3">
                                                    <label for="password" class="form-label text-dark">Nhập
                                                        password</label>
                                                    <input type="text" class="form-control" id="password"
                                                           name="password" required>
                                                </div>

                                                <button type="submit" class="btn btn-primary">Kiểm Tra</button>
                                            </form>

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                                Đóng
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="room-info my-3">
                                <?php if(session("motel_unlocked_{$motel->id}")): ?>
                                    <div class="actions d-flex justify-content-between">
                                        <button class="btn btn-info"
                                                onclick="window.location.href='<?php echo e(route('admin.motel.addUserMotel', ['id' => $motel->id])); ?>'">
                                            <i class="fas fa-user-friends"></i>
                                        </button>
                                        <?php if(isset($motel->getInvoicesBy($motel->id)->first()->id)): ?>
                                            <button class="btn btn-warning"
                                                    onclick="window.location.href='<?php echo e(route('admin.invoices.pay', ['id' => $motel->getInvoicesBy($motel->id)->first()->id])); ?>'">
                                                <i class="fas fa-receipt"></i>
                                            </button>
                                        <?php endif; ?>
                                        <button class="btn btn-purple" data-bs-toggle="modal"
                                                data-bs-target="#addMemberModal<?php echo e($motel->id); ?>">
                                            <i class="fas fa-file-invoice"></i></button>

                                        <form action="<?php echo e(route('admin.motel.leave')); ?>"
                                              method="POST" style="display: inline;">
                                            <?php echo csrf_field(); ?>

                                            <button type="submit" class="btn btn-danger"
                                                    onclick="return confirm('Bạn có muốn thoát phòng không?')">
                                                <i class="fas fa-sign-out-alt"></i></button>
                                        </form>
                                    </div>
                                <?php else: ?>
                                    <p class="text-danger">Bạn cần nhập đúng mật khẩu để mở khóa phòng.</p>
                                <?php endif; ?>
                            </div>
                            <div class="card-footer text-center row">
                                <div class="col-md-6  ">
                                    <p>Ngày tính
                                        tiền: <?php echo e(\Carbon\Carbon::parse($motel->money_date)->format('d/m/Y')); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p>Tiền phòng: <?php echo e(number_format($motel->money,0,',', '.')); ?> đ</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>

            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <div class="card room-card">
                        <!-- Header -->
                        <div class="card-header text-center bg-warning">
                            <img class="img-fluid" src="<?php echo e(asset('uploads/logoCodeCrib.png')); ?>">
                        </div>
                        <!-- Body -->
                        <div class="card-body">
                            <h6 class="room-name">Bạn chưa có phòng nào hết, mau đăng ký lẹ đi</h6>

                            <div class="card-footer text-center row">
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>

            </div>
        <?php endif; ?>
    </main>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin_core.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin_core/content/motel/room-access.blade.php ENDPATH**/ ?>