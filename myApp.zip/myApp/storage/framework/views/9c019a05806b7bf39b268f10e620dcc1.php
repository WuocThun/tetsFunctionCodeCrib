<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('fe.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('searchBar'); ?>
    <?php echo $__env->make('fe.inc.search_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('hotZone'); ?>
    <?php echo $__env->make('fe.inc.hot_zone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <style>
        .call-btn {
            background-color: #007bff;
            border: none;
            font-size: 14px;
            color: white;
        }
    </style>
    <section class="search-results">
<div class="container">
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

</div>
        <div class="container search-results-container">

            <div class="results-left">
                <h2>Tổng <?php echo e(count($motels)); ?> kết quả phòng trọ còn trống</h2>
                <?php $__currentLoopData = $motels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room => $motel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <a href="<?php echo e(route('getRoom',$motel->slug)); ?>" style="text-decoration: none;">
                        <div class="result-item">
                            <?php
                                $images = json_decode($motel->image, true);
                            ?>
                            <img src="<?php echo e(asset('uploads/fe/img/room1.jpg')); ?>" alt="Ký túc xá Tân Bình">
                            <div class="result-info">
                                <h3 ><?php echo e($motel->name); ?></h3>
                                <p><?php echo e(number_format($motel->money,0,',', '.')); ?> nghìn/tháng - <?php echo e($motel->area); ?>m² </p>
                                <p><?php echo e($motel->full_address); ?></p>

                                
                                <div class="contact-options">
                                    <button class="btn  call-btn ">Gọi <?php echo e($motel->phone_number); ?></button>

                                    <form action="<?php echo e(route('room-requests.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="motel_id" value="<?php echo e($motel->id); ?>">
                                        <button type="submit" class="btn btn-warning">Yêu cầu tham gia</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="pagination">
                    <?php if($motels->onFirstPage()): ?>
                        <button class="prev" disabled>« Trang trước</button>
                    <?php else: ?>
                        <a href="<?php echo e($motels->previousPageUrl()); ?>" class="prev">« Trang trước</a>
                    <?php endif; ?>

                    <?php for($page = 1; $page <= $motels->lastPage(); $page++): ?>
                        <a href="<?php echo e($motels->url($page)); ?>" class="page <?php echo e($page == $motels->currentPage() ? 'active' : ''); ?>"><?php echo e($page); ?></a>
                    <?php endfor; ?>

                    <?php if($motels->hasMorePages()): ?>
                        <a href="<?php echo e($motels->nextPageUrl()); ?>" class="next">Trang sau »</a>
                    <?php else: ?>
                        <button class="next" disabled>Trang sau »</button>
                    <?php endif; ?>
                </div>

            </div>

            <?php echo $__env->make('fe.inc.fitler_blogs_right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

    </section>
    <script>

        document.addEventListener('DOMContentLoaded', function () {
            document.querySelectorAll('.add-to-wishlist').forEach(function (button) {
                button.addEventListener('click', function (e) {
                    e.preventDefault(); // Ngăn chặn hành vi mặc định của trình duyệt

                    let roomId = this.dataset.roomId;

                    fetch('<?php echo e(route("wishlist.add")); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                        },
                        body: JSON.stringify({ room_id: roomId }),
                    })
                        .then(response => {
                            const contentType = response.headers.get('content-type');
                            if (!contentType || !contentType.includes('application/json')) {
                                throw new Error('Server did not return JSON');
                            }
                            return response.json();
                        })
                        .then(data => {
                            if (data.status === 'success') {
                                showPopup(data.message, 'success');
                            } else {
                                showPopup(data.message, 'error');
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            showPopup('Đã xảy ra lỗi. Vui lòng thử lại sau.', 'error');
                        });
                });
            });

            function showPopup(message, type) {
                const popup = document.createElement('div');
                popup.className = `popup-message ${type}`;
                popup.innerText = message;

                document.body.appendChild(popup);

                setTimeout(() => {
                    popup.remove();
                }, 3000);
            }
        });



    </script>

    <style>
        .popup-message {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 15px 20px;
            color: #fff;
            border-radius: 5px;
            z-index: 9999;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            animation: fadeIn 0.5s ease-out;
        }

        .popup-message.success {
            background-color: #4caf50;
        }

        .popup-message.error {
            background-color: #f44336;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('overView'); ?>
    <?php echo $__env->make('fe.inc.over_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('fe.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('fe.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/fe/phongtrocontrong.blade.php ENDPATH**/ ?>