

<footer class="footer">
    <div class="container footer-container">
        <div class="footer-top">
            <div class="footer-column">
                <h4>Thông tin</h4>
                <ul>
                    <li><a href="#">Giới thiệu</a></li>
                    <li><a href="#">Liên hệ</a></li>
                    <li><a href="#">Chính sách bảo mật</a></li>
                    <li><a href="#">Điều khoản sử dụng</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h4>Dịch vụ</h4>
                <ul>
                    <li><a href="#">Cho thuê phòng trọ</a></li>
                    <li><a href="#">Cho thuê nhà nguyên căn</a></li>
                    <li><a href="#">Cho thuê căn hộ</a></li>
                    <li><a href="#">Cho thuê mặt bằng</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h4>Kết nối với chúng tôi</h4>
                <ul class="social-icons">
                    <li><a href="#"><div class="imgfb"></div></a></li>
                    <li><a href="#"><div class="imgyt"></div></a></li>
                    <li><a href="#"><div class="imgzl"></div></a></li>
                    <li><a href="#"><div class="imgtw"></div></a></li>

                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 CodeCrib. Tất cả quyền được bảo lưu.</p>
        </div>
    </div>
</footer>
