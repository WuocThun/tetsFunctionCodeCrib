<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('style/css/admin.css')}}">
</head>

<body class="desktop dashboard quan-ly dang-tin dang-tin-moi">
<div id="webpage">
    <div class="container-fluid">
        <div class="row">




        </div>
    </div>


</div><!-- end webpage -->

</body>

</html>
